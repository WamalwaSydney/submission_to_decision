<#
drip-push.ps1

Splits your uncommitted work into several commits and pushes each one at a random
time between now and the next occurrence of -FinishBy (default 08:30, i.e. an hour
before a 09:30 deadline). Commit times are REAL (nothing is backdated).

This script never commits or pushes itself: it adds its own name to .git/info/exclude
(a local-only ignore list) and filters itself out of every batch.

Run from the repo folder in PowerShell:
  .\drip-push.ps1 -DryRun       # show the plan only
  .\drip-push.ps1               # do it; keep the window open and the laptop plugged in
  .\drip-push.ps1 -Batches 1    # push everything in one commit right now

If scripts are blocked:  Set-ExecutionPolicy -Scope Process Bypass
#>
param(
  [string]$RemoteUrl     = "https://github.com/WamalwaSydney/submission_to_decision.git",
  [string]$Branch        = "main",
  [int]   $Batches       = 0,      # 0 = automatic: about FilesPerBatch files per commit, max 12
  [int]   $FilesPerBatch = 6,
  [string]$FinishBy      = "08:30",
  [int]   $MinGapMinutes = 10,
  [switch]$DryRun
)

$ErrorActionPreference = "Continue"
$ScriptName = if ($PSCommandPath) { Split-Path -Leaf $PSCommandPath } else { "drip-push.ps1" }

function Invoke-Git {
  & git @args
  if ($LASTEXITCODE -ne 0) { throw "git $($args -join ' ') failed (exit $LASTEXITCODE)" }
}

# ---------- sanity checks ----------
if (-not (Test-Path ".git")) { throw "Run this from the repo folder (no .git here)." }
$uName  = (& git config user.name)
$uEmail = (& git config user.email)
if (-not $uName -or -not $uEmail) {
  throw 'Set your git identity first: git config --local user.name "Your Name"; git config --local user.email "you@example.com"'
}

# Never let this script into the repo (local-only ignore, not part of the project)
$excludeFile = Join-Path ".git" "info\exclude"
New-Item -ItemType Directory -Force -Path (Split-Path $excludeFile) | Out-Null
if (-not (Test-Path $excludeFile) -or -not (Select-String -Path $excludeFile -SimpleMatch -Pattern $ScriptName -Quiet)) {
  Add-Content -Path $excludeFile -Value $ScriptName
}

# Refuse to continue if the local history still has qwen commits
& git rev-parse --verify HEAD *> $null
if ($LASTEXITCODE -eq 0) {
  $bad = @(& git log --format="%an|%ae|%cn|%ce|%B" | Select-String -Pattern "qwen")
  if ($bad.Count -gt 0) {
    throw "Local history still contains 'qwen' commits. Reset the history first (new git init + force push), then run this again."
  }
}

if (-not (Test-Path ".gitignore")) {
@"
node_modules/
dist/
build/
.env
.env.*
!.env.example
__pycache__/
*.pyc
.venv/
venv/
uploads/
.DS_Store
"@ | Set-Content -Encoding ascii .gitignore
  Write-Host "Created a default .gitignore (node_modules, .env, dist, etc.)."
}

# ---------- remote + branch ----------
$remotes = @(& git remote)
if ($remotes -notcontains "origin") { Invoke-Git remote add origin $RemoteUrl }

& git rev-parse --verify HEAD *> $null
if ($LASTEXITCODE -eq 0) {
  $cur = (& git symbolic-ref --short HEAD)
  if ($cur -ne $Branch) { Invoke-Git branch -M $Branch }
}

& git fetch origin *> $null
$remoteHas = (& git ls-remote --heads origin $Branch)
if ($remoteHas -and -not $DryRun) {
  $behind = [int](& git rev-list --count "HEAD..origin/$Branch")
  if ($behind -gt 0) { Invoke-Git pull --rebase --autostash origin $Branch }
}

# ---------- make sure the script itself is not tracked ----------
if (-not $DryRun) {
  Invoke-Git reset -q    # unstage so batches are clean (working files untouched)
  & git ls-files --error-unmatch $ScriptName *> $null
  if ($LASTEXITCODE -eq 0) {
    Invoke-Git rm --cached -q -- $ScriptName
    Invoke-Git commit -q -m "Stop tracking helper script"
    Write-Warning "$ScriptName was tracked; it is now removed from the repo. If it was already pushed, it stays visible in older commits."
  }
}

# ---------- collect changes ----------
$files = @(& git ls-files -m -o --exclude-standard) + @(& git diff --cached --name-only)
$files = @($files | Where-Object { $_ -and ($_ -ne $ScriptName) -and (Test-Path -LiteralPath $_) } | Sort-Object -Unique)

$blocked = @($files | Where-Object { $_ -match '(^|/)\.env($|\.)' -and $_ -notmatch '\.example$' })
if ($blocked.Count -gt 0) {
  throw "Refusing to commit secret-looking files: $($blocked -join ', '). Add them to .gitignore."
}
if ($files.Count -gt 3000) {
  throw "$($files.Count) files to commit - node_modules or build output is probably not ignored. Check .gitignore."
}

# ---------- batches ----------
if ($Batches -gt 0) { $want = $Batches }
else { $want = [int][Math]::Min(12, [Math]::Max(1, [Math]::Ceiling($files.Count / [double]$FilesPerBatch))) }

$chunks = @()
if ($files.Count -gt 0) {
  $n    = [Math]::Max(1, [Math]::Min($want, $files.Count))
  $size = [int][Math]::Ceiling($files.Count / [double]$n)
  for ($i = 0; $i -lt $files.Count; $i += $size) {
    $last = [Math]::Min($i + $size, $files.Count) - 1
    $chunks += ,@($files[$i..$last])
  }
}

# ---------- schedule ----------
$now = Get-Date
$hm  = $FinishBy.Split(":")
$end = $now.Date.AddHours([int]$hm[0]).AddMinutes([int]$hm[1])
if ($end -le $now.AddMinutes(30)) { $end = $end.AddDays(1) }

$count = $chunks.Count - 1
$times = @()
if ($count -gt 0) {
  $rand = New-Object System.Random
  $span = ($end - $now).TotalMinutes - $MinGapMinutes
  if ($span -lt $count) { throw "Not enough time before $FinishBy for $($chunks.Count) batches. Lower -Batches." }
  $gap = $MinGapMinutes
  for ($attempt = 0; $attempt -lt 2000; $attempt++) {
    if ($attempt -eq 1000) { $gap = [Math]::Max(1, [int]($gap / 2)) }
    $t  = @(1..$count | ForEach-Object { $now.AddMinutes($MinGapMinutes + $rand.NextDouble() * $span) } | Sort-Object)
    $ok = $true
    for ($j = 1; $j -lt $t.Count; $j++) { if (($t[$j] - $t[$j-1]).TotalMinutes -lt $gap) { $ok = $false; break } }
    if ($ok) { $times = $t; break }
  }
  if ($times.Count -ne $count) { throw "Could not build a schedule. Lower -Batches or raise -FinishBy." }
}

function Get-Group($p) {
  $seg = $p -split '/'
  if ($seg.Count -le 1) { return $p }
  elseif ($seg.Count -eq 2) { return $seg[0] }
  else { return "$($seg[0])/$($seg[1])" }
}
function Get-Msg($paths) {
  $groups = @($paths | ForEach-Object { Get-Group $_ } | Sort-Object -Unique)
  $top = ($groups | Select-Object -First 3) -join ", "
  $more = $groups.Count - 3
  if ($more -gt 0) { return "Add $top and $more more areas" } else { return "Add $top" }
}

Write-Host ""
Write-Host "Commits will be authored as: $uName <$uEmail>"
Write-Host "Not included in any commit : $ScriptName"
Write-Host "Files to commit: $($files.Count)   Batches: $($chunks.Count)   Finish by: $($end.ToString('ddd dd MMM HH:mm'))"
for ($i = 0; $i -lt $chunks.Count; $i++) {
  $when = if ($i -eq 0) { $now } else { $times[$i-1] }
  $label = if ($i -eq 0) { "now" } else { $when.ToString("ddd dd MMM HH:mm") }
  Write-Host ("  {0,2}. {1,-16} {2,4} files  {3}" -f ($i + 1), $label, $chunks[$i].Count, (Get-Msg $chunks[$i]))
}
Write-Host ""
if ($DryRun) { Write-Host "Dry run only - nothing committed or pushed."; return }
if ($chunks.Count -eq 0) { Write-Host "No changes to commit. Pushing existing commits." }

# ---------- helpers ----------
function Wait-Until($t) { while ((Get-Date) -lt $t) { Start-Sleep -Seconds 20 } }

function Push-Retry {
  for ($try = 1; $try -le 5; $try++) {
    & git push -u origin $Branch
    if ($LASTEXITCODE -eq 0) { return $true }
    Write-Host "Push failed (attempt $try of 5). Retrying in 60s..."
    Start-Sleep -Seconds 60
  }
  Write-Warning "Push still failing; it will be retried with the next batch."
  return $false
}

# keep Windows awake while this runs
try {
  Add-Type -Namespace Win -Name Power -MemberDefinition '[DllImport("kernel32.dll")] public static extern uint SetThreadExecutionState(uint f);'
  [Win.Power]::SetThreadExecutionState(0x80000001) | Out-Null
} catch { }

# ---------- go ----------
Write-Host "Pushing any existing local commits now so the repo is not empty..."
& git rev-parse --verify HEAD *> $null
if ($LASTEXITCODE -eq 0) { Push-Retry | Out-Null }

for ($i = 0; $i -lt $chunks.Count; $i++) {
  if ($i -gt 0) {
    Write-Host "Next batch at $($times[$i-1].ToString('ddd dd MMM HH:mm')) ..."
    Wait-Until $times[$i-1]
  }
  $paths = $chunks[$i]
  $paths | & git add --pathspec-from-file=-
  & git diff --cached --quiet
  if ($LASTEXITCODE -ne 0) {
    Invoke-Git commit -q -m (Get-Msg $paths)
    Write-Host "[$((Get-Date).ToString('HH:mm'))] committed batch $($i + 1)/$($chunks.Count)"
  }
  Push-Retry | Out-Null
}

# final sweep: anything left over (e.g. deletions), still never the script itself
& git add -A
& git reset -q -- $ScriptName *> $null
& git diff --cached --quiet
if ($LASTEXITCODE -ne 0) { Invoke-Git commit -q -m "Final touches"; Push-Retry | Out-Null }

try { [Win.Power]::SetThreadExecutionState(0x80000000) | Out-Null } catch { }
Write-Host ""
Write-Host "Done. Check https://github.com/WamalwaSydney/submission_to_decision and run: git log --format='%h %an <%ae>'"